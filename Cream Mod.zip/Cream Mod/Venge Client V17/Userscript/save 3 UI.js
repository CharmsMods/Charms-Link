// AI was used to help with coding becuase I can't code very well yet haha, everything has been labled purpose wise for ez lookup
// Combined Venge.io Enhancement Script with Cream Theme
// Merges functionality from bettervision.js and customsetting.js

// Custom weapon position
const weaponPosition = { x: 0, y: 0, z: 0.80 };

// Override the setHeroSkin method for enhanced character materials
pc.Application.getApplication().once("postrender", function () {
    // Override setHeroSkin method to add emission effects
    pc.app.scripts.list()[11].prototype.setHeroSkin = function() {
        var self = this;
        var skinName = this.heroSkin;

        if(this.heroSkin == 'Default') {
            skinName = this.hero + '-' + this.heroSkin + '.jpg';
        }

        if(skinName && this.characterEntity) {
            if(skinName.search('Model-') > -1 || skinName.search('.glb') > -1) {
                var assetID = this.app.assets.find(skinName).id;
                this.characterEntity.model.asset = assetID;

                var asset = this.app.assets.get(assetID);
                asset.ready(function() {
                    self.handEntity = self.characterEntity.findByName(self.handEntityName);
                    self.weaponHolder.reparent(self.handEntity);
                    console.log('Loaded model skin ' + self.username);
                });
            } else {
                var material = this.characterEntity.model.material.clone();
                var texture = pc.app.assets.find(this.hero + '-' + this.heroSkin + '.jpg');
                var meshInstances = this.characterEntity.model.meshInstances;

                if(meshInstances && meshInstances.length > 0) {
                    for (var i = 0; i < meshInstances.length; ++i) {
                        var mesh = meshInstances[i];
                        mesh.material = material;

                        // Add bright white emission
                        material.emissive = new pc.Color(1, 1, 1);
                        material.emissiveIntensity = 10000;
                        material.update();
                    }

                    if(texture) {
                        material.diffuseMap = texture.resource;
                        material.update();
                    }
                }
                this.weaponHolder.reparent(this.handEntity);
            }
            this.characterEntity.animation.play('Idle');
        } else {
            this.weaponHolder.reparent(this.handEntity);
        }
    };

    // Override createPlayer method to maintain skin customizations
    pc.app.scripts.list()[9].prototype.createPlayer = function(data) {
        var player = this.enemyEntity.clone();
        player.enabled = true;
        player.script.enemy.playerId = data.playerId;
        player.script.enemy.username = data.username;
        player.script.enemy.team = data.team;
        player.script.enemy.level = data.level;
        player.script.enemy.group = data.group;

        player.script.enemy.skin = data.skin;
        player.script.enemy.heroSkin = data.heroSkin;

        player.script.enemy.setUsername(data.username, data.team, data.level);
        player.script.enemy.killMessage = data.killMessage;

        // Set weapon
        player.script.enemy.weaponSkins = data.weaponSkins;
        player.script.enemy.setWeapon(data.weapon);
        player.script.enemy.setCharacterSkin(data.skin, 'Default', data.dance);

        this.playerHolder.addChild(player);
        this.players.push(player);
    };
});

// Player Join event handler for Shin character special handling
pc.app.on("Game:PlayerJoin", (state) => {
    var shinTexture = pc.app.assets.find('Shin-Default.jpg');
    if (state) {
        for (let i = 2; i <= pc.app.root.findByName("Game").findByName("PlayerHolder").children.length - 1; i++) {
            let player = pc.app.root.findByName('PlayerHolder').children[i];
            if(player.script.enemy.skin != 'Shin'){
                player.script.enemy.setCharacterSkin(player.script.enemy.skin, "Default", player.script.enemy.danceName);
            } else {
                let shinMaterial = player.findByName('ModelHolder').findByName('Shin').model.meshInstances[0].material;
                shinMaterial.diffuse = shinTexture.resource;
                shinMaterial.emissive = new pc.Color(1, 1, 1);
                shinMaterial.emissiveIntensity = 1000;
                shinMaterial.update();
            }
        }
    }
});

// Main enhancement function that runs after map loads
pc.app.on("Map:Loaded", () => {
    setTimeout(() => {
        const game = pc.app.root.findByName("Game");
        if (!game) {
            console.error("Game not found. Script terminated.");
            return;
        }

        // 1. Clean up UI elements
        cleanupUI(game);
        
        // 2. Hide character hands
        hideHands();
        
        // 3. Adjust weapon position
        adjustWeaponPosition();
        
        // 4. Apply map-specific lighting settings
        applyMapLighting();
        
        // 5. Apply additional UI modifications from customsetting.js
        applyAdditionalUIChanges();
        
        console.log("Venge.io enhancement complete");
    }, 2000); // Use 2000ms timeout to ensure everything loads properly
});

// Auto-leave functionality
pc.app.on("Player:Leave", () => {
    setTimeout(() => {
        document.querySelectorAll('.options a')[3].click();
    }, 1500);
});

// Initial menu selection
setTimeout(() => {
    document.querySelectorAll('.options a')[3].click();
}, 2000);

// Helper Functions

function cleanupUI(game) {
    try {
        // Disable popup elements
        ["UnlockItemReward", "Notification", "AnnouncementBox"].forEach(item => {
            const element = game.findByName(item);
            if (element) element.enabled = false;
        });

        // Remove ads
        [166, 175, 180].forEach(index => {
            if (pc.app.scripts.list()[index]) {
                pc.app.scripts.list()[index].prototype.showAds = null;
                pc.app.scripts.list()[index].prototype.preroll = null;
            }
        });

        // Modify leaderboard visibility with cream theme
        const overlay = game.findByName("Overlay");
        if (overlay) {
            pc.app.on("Overlay:Leaderboard", () => {
                const leaderboard = overlay.findByName("Leaderboard");
                if (leaderboard) {
                    leaderboard.children.forEach((child) => {
                        if (child.element) {
                            // Make leaderboard nearly invisible (0.0 opacity) with cream background
                            child.element.opacity = 0.5;
                            child.element.color = new pc.Color(0.8, 0.7, 0.6); // Soft tan cream color
                        }
                    });
                }
            });
            
            // Reduce opacity of non-essential HUD elements
            const hud = overlay.findByName("HUD");
            if (hud) {
                ["AmmoDisplay", "KillFeed", "KillCard"].forEach(element => {
                    const hudComponent = hud.findByName(element);
                    if (hudComponent && hudComponent.element) {
                        hudComponent.element.opacity = 0.5;
                        hudComponent.element.color = new pc.Color(0.9, 0.8, 0.7); // Creamy tan HUD text
                    }
                });
            }
        }
    } catch (error) {
        console.error("Error in UI cleanup:", error);
    }
}

function hideHands() {
    try {
        const weaponCenter = pc.app.root.findByName("WeaponCenter");
        if (weaponCenter) {
            const handsHolder = weaponCenter.findByName("CharacterHandsHolder");
            if (handsHolder) {
                handsHolder.setLocalScale(0, 0, 0);
                pc.settings.hideArms = true;
            }
        }
    } catch (error) {
        console.error("Error hiding hands:", error);
    }
}

function adjustWeaponPosition() {
    try {
        // Set initial weapon position
        const weaponCenter = pc.app.root.findByName("WeaponCenter");
        if (weaponCenter) {
            weaponCenter.setLocalPosition(
                weaponPosition.x, 
                weaponPosition.y, 
                weaponPosition.z
            );
        }
        
        // Update position when not aiming
        pc.app.on('Player:Focused', function(state) {
            if (!state) {
                const weaponCenter = pc.app.root.findByName("WeaponCenter");
                if (weaponCenter) {
                    weaponCenter.setLocalPosition(
                        weaponPosition.x, 
                        weaponPosition.y, 
                        weaponPosition.z
                    );
                }
            }
        });
    } catch (error) {
        console.error("Error adjusting weapon position:", error);
    }
}

function applyMapLighting() {
    try {
        const mode = window.mapMode || "light"; // "light" or "golden"

        // If mode is "light", we simply exit the function to do nothing
        if (mode === "light") {
            return;  // Disable any lighting changes for light mode
        }

        let exposure = 1.0;
        let skyboxIntensity = 1.5;
        let lightColor = { r: 1, g: 1, b: 1, a: 1 }; // Default white lighting

        if (mode === "golden") {
            exposure = 0.4;
            skyboxIntensity = 2.0;
            lightColor = { r: 1.0, g: 0.85, b: 0.6, a: 1 }; // Golden lighting
        }

        // Apply the selected lighting mode to the scene (for golden mode)
        pc.app.renderer.scene.exposure = exposure;
        pc.app.renderer.scene.skyboxIntensity = skyboxIntensity;

        const sceneLight = pc.app.root.findByName("Light");
        if (sceneLight && sceneLight.light) {
            sceneLight.light.color = lightColor;
        }
    } catch (e) {
        console.error("Error applying map lighting:", e);
    }
}

function applyAdditionalUIChanges() {
    try {
        // Additional UI modifications with cream color accents
        const overlay = pc.app.root.findByName("Overlay");
        if (overlay) {
            // Hide various UI elements
            overlay.findByName("TimesAndScore").findByName("Background").enabled = false;
            overlay.findByName("728x90-Banner").element.opacity = 0;
            overlay.findByName("728x90-Banner").element.color = new pc.Color(0.8, 0.7, 0.6); // Creamy tan background for banner
        }
    } catch (error) {
        console.error("Error applying additional UI changes:", error);
    }
}
