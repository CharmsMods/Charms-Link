// === Map Config and lighting for Cream Mod ===
// Change values here to affect how the mod behaves









// Weapon position (1 = default, 0 = down, 2 = high)
window.weaponPosition = 0;

// Set map lighting mode: "golden" for golden hour effect, "dark" for dark mode
window.mapMode = "golden";

